//
//  UsefulAppStarkTests.swift
//  UsefulAppStarkTests
//
//  Created by RYAN STARK on 10/28/24.
//

import Testing
@testable import UsefulAppStark

struct UsefulAppStarkTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
